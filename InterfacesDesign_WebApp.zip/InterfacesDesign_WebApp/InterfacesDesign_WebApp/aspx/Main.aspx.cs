﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace InterfacesDesign_WebApp.aspx
{
    public partial class Main : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (this.Page.IsPostBack == false)
            {

                frameContent.Attributes["src"] = "Attendance.aspx";
                lblDate.Text = Convert.ToDateTime(DateTime.Now).ToString("dd/MMM/yyyy");

            }
        }

        protected void btnAttendance_Click(object sender, EventArgs e)
        {
            frameContent.Attributes["src"] = "Attendance.aspx";
        }

        
    }
}